import 'package:denz_sen/core/theme/app_colors.dart';
import 'package:denz_sen/core/theme/app_spacing.dart';
import 'package:denz_sen/core/theme/app_style.dart';
import 'package:denz_sen/core/widget/custom_button.dart';
import 'package:denz_sen/feature/auth/new_password/screen/new_password_screen.dart';
import 'package:denz_sen/feature/success_screen/success_screen_bottom_sheet.dart';
import 'package:denz_sen/feature/verification/provider/verification_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum OtpSource { signup, passwordReset }

class VerificationPage {
  static void show(BuildContext context, {required OtpSource otpSource}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) {
        return _VerificationBottomSheet(otpSource: otpSource);
      },
    );
  }
}

class _VerificationBottomSheet extends StatefulWidget {
  const _VerificationBottomSheet({required this.otpSource});

  final OtpSource otpSource;

  @override
  State<_VerificationBottomSheet> createState() =>
      _VerificationBottomSheetState();
}

class _VerificationBottomSheetState extends State<_VerificationBottomSheet> {
  final List<TextEditingController> _otpControllers = List.generate(
    6,
    (_) => TextEditingController(),
  );
  final List<FocusNode> _focusNodes = List.generate(6, (_) => FocusNode());
  bool _isOtpFilled = false;

  @override
  void initState() {
    super.initState();
    // Load user data when the page opens
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = Provider.of<VerificationProvider>(
        context,
        listen: false,
      );
      provider.setOtpSource(widget.otpSource);
      provider.loadUserData();
    });
  }

  @override
  void dispose() {
    for (var controller in _otpControllers) {
      controller.dispose();
    }
    for (var focusNode in _focusNodes) {
      focusNode.dispose();
    }
    super.dispose();
  }

  void _checkOtpFilled() {
    setState(() {
      _isOtpFilled = _otpControllers.every(
        (controller) => controller.text.isNotEmpty,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: SingleChildScrollView(
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16.w),
              topRight: Radius.circular(16.w),
            ),
          ),
          child: Padding(
            padding: EdgeInsets.all(16.w),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: SizedBox(
                    width: 60.w,
                    height: 6.h,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        color: AppColors.grey.withValues(alpha: 0.5),
                        borderRadius: BorderRadius.circular(3.r),
                      ),
                    ),
                  ),
                ),
                AppSpacing.h8,
                BottomSheetIconText(title: 'Verify Your Account'),
                AppSpacing.h10,
                // Show user info only for signup
                if (widget.otpSource == OtpSource.signup) ...[
                  CircleAvatar(
                    radius: 40.r, // size of the avatar
                    backgroundColor: AppColors.grey.withValues(
                      alpha: 0.1,
                    ), // light gray background
                    child: Icon(
                      Icons.person, // default profile icon
                      size: 40.r, // icon size
                      color: AppColors.primaryColor, // icon color
                    ),
                  ),
                  AppSpacing.h10,
                  Consumer<VerificationProvider>(
                    builder: (context, provider, _) => Text(
                      provider.name ?? 'User',
                      style: AppStyle.semiBook16,
                    ),
                  ),
                  AppSpacing.h2,
                  Consumer<VerificationProvider>(
                    builder: (context, provider, _) => Text(
                      provider.email ?? 'No Email',
                      style: AppStyle.book14.copyWith(fontSize: 12.sp),
                    ),
                  ),
                  AppSpacing.h16,
                ],
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.primaryColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: ListTile(
                    leading: Icon(
                      Icons.error,
                      color: AppColors.primaryColor,
                      size: 28.sp,
                    ),
                    title: Text(
                      'We have send you 6 digits verification code to your email. Please kindly check',
                      style: AppStyle.book16.copyWith(
                        fontSize: 12.sp,
                        color: AppColors.primaryColor,
                      ),
                    ),
                  ),
                ),
                AppSpacing.h16,
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    6,
                    (index) => Container(
                      margin: EdgeInsets.symmetric(horizontal: 4.w),
                      width: 46.w,
                      height: 52.h,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10.r),
                      ),
                      alignment: Alignment.center,
                      child: TextField(
                        controller: _otpControllers[index],
                        focusNode: _focusNodes[index],
                        textAlign: TextAlign.center,
                        textAlignVertical: TextAlignVertical.center,
                        keyboardType: TextInputType.number,
                        maxLength: 1,
                        style: TextStyle(
                          fontSize: 20.sp,
                          fontWeight: FontWeight.bold,
                          height: 1.2,
                        ),
                        decoration: InputDecoration(
                          counterText: "",
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.r),
                            borderSide: BorderSide(
                              color: _focusNodes[index].hasFocus
                                  ? AppColors.border
                                  : AppColors.primaryColor,
                              width: 2.0,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.r),
                            borderSide: BorderSide(
                              color: AppColors.primaryColor,
                              width: 2.0,
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.r),
                            borderSide: BorderSide(
                              color: AppColors.border,
                              width: 1.0,
                            ),
                          ),
                          contentPadding: EdgeInsets.symmetric(
                            horizontal: 4,
                            vertical: 16,
                          ),
                        ),
                        cursorColor: AppColors.primaryColor,
                        onChanged: (value) {
                          if (value.length == 1 && index < 5) {
                            _focusNodes[index + 1].requestFocus();
                          }
                          if (value.isEmpty && index > 0) {
                            _focusNodes[index - 1].requestFocus();
                          }
                          _checkOtpFilled();
                        },
                      ),
                    ),
                  ),
                ),
                AppSpacing.h28,

                Consumer<VerificationProvider>(
                  builder: (context, provider, _) {
                    return CustomButton(
                      isLoading: provider.isLoading,
                      onPressed: _isOtpFilled && !provider.isLoading
                          ? () async {
                              debugPrint('===== Verify Button Pressed =====');

                              final otp = _otpControllers
                                  .map((controller) => controller.text)
                                  .join();

                              debugPrint('OTP Entered: $otp');
                              debugPrint('OTP Length: ${otp.length}');

                              // Get email from SharedPreferences
                              final prefs =
                                  await SharedPreferences.getInstance();
                              final email = prefs.getString('email') ?? '';

                              debugPrint(
                                'Email from SharedPreferences: $email',
                              );

                              if (email.isEmpty) {
                                debugPrint(
                                  'ERROR: Email not found in SharedPreferences',
                                );
                                if (mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                        'Email not found. Please sign up again.',
                                      ),
                                    ),
                                  );
                                }
                                return;
                              }

                              // Call API based on OTP source
                              debugPrint('Calling verifyOtp API...');
                              final success =
                                  widget.otpSource == OtpSource.passwordReset
                                  ? await provider.verifyResetOtp(email, otp)
                                  : await provider.verifyOtp(email, otp);

                              debugPrint('API Response Success: $success');

                              if (!mounted) return;

                              if (success) {
                                debugPrint(
                                  'Verification Success - Showing Success Screen',
                                );
                                Navigator.of(context).pop();

                                // Navigate based on OTP source
                                if (widget.otpSource == OtpSource.signup) {
                                  // Show success screen for signup
                                  SuccessScreenBottomSheet.show(
                                    context,
                                    type: SuccessType.verify,
                                  );
                                } else if (widget.otpSource ==
                                    OtpSource.passwordReset) {
                                  // Navigate to change password screen
                                  NewPasswordScreen.show(context);
                                }
                              } else {
                                debugPrint(
                                  'Verification Failed - Showing Error: ${provider.errorMessage}',
                                );
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      provider.errorMessage ??
                                          'Verification failed',
                                    ),
                                  ),
                                );
                              }
                            }
                          : null,
                      buttonText: 'Verify',
                      backgroundColor: _isOtpFilled && !provider.isLoading
                          ? AppColors.primaryColor
                          : AppColors.grey.withValues(alpha: 0.5),
                    );
                  },
                ),

                AppSpacing.h32,
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class BottomSheetIconText extends StatelessWidget {
  const BottomSheetIconText({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: Icon(Icons.arrow_back_ios, size: 20.sp),
        ),
        Text(title, style: AppStyle.semiBook18),
      ],
    );
  }
}
